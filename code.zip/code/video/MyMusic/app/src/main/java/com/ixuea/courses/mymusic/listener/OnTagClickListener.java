package com.ixuea.courses.mymusic.listener;

/**
 * Created by smile on 2018/6/9.
 */

public interface OnTagClickListener {
    void onTagClick(String content);
}
