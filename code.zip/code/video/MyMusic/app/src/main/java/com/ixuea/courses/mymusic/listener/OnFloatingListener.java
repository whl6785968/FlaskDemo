package com.ixuea.courses.mymusic.listener;

/**
 * Created by smile on 2018/6/3.
 */

public interface OnFloatingListener {
    void onPlayClick();
    void onPrevious();
    void onNext();
}
