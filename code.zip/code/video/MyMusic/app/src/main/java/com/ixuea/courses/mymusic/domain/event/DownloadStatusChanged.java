package com.ixuea.courses.mymusic.domain.event;

import cn.woblog.android.downloader.domain.DownloadInfo;

/**
 * Created by smile on 2018/6/8.
 */

public class DownloadStatusChanged {
    public DownloadStatusChanged(DownloadInfo downloadInfo) {

    }
}
