package com.ixuea.courses.mymusic.listener;

/**
 * Created by smile on 2018/5/29.
 */

public interface OnLyricClickListener {
    void onLyricClick(long time);
}
