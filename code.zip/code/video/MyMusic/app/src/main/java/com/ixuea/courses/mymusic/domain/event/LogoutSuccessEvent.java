package com.ixuea.courses.mymusic.domain.event;

/**
 * Created by smile on 2018/5/26.
 */

public class LogoutSuccessEvent {
}
