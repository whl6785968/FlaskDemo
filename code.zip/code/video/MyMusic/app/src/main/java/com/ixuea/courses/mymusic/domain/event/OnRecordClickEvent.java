package com.ixuea.courses.mymusic.domain.event;

public class OnRecordClickEvent {
}
