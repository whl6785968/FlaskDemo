package com.ixuea.courses.mymusic.reactivex;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by smile on 03/03/2018.
 */

public class AbsObserver<T> implements Observer<T> {
    @Override
    public void onSubscribe(Disposable d) {

    }

    @Override
    public void onNext(T t) {
    }

    @Override
    public void onError(Throwable e) {

    }

    @Override
    public void onComplete() {

    }

}
