package com.ixuea.courses.mymusic.domain;

import java.io.Serializable;

/**
 * Created by smile on 2018/5/30.
 */

public class Base implements Serializable {
}
