package cn.woblog.android.downloader.core.task;

/**
 * Created by renpingqing on 17/1/22.
 */

public interface DownloadTask {

  void start();
}
